document.addEventListener('DOMContentLoaded', function() {
    // Функция для показа уведомления
    function showNotification(message) {
        const notification = document.createElement('div'); 
        notification.className = 'notification'; 
        notification.textContent = message; 
        document.body.appendChild(notification); 

        // Удаляем уведомление через 1.5 секунды
        setTimeout(function() {
            notification.remove();
        }, 1500);
    }

    // Переменная для хранения продуктов
    let products = [];

    // Функция для отображения продуктов
    function displayProducts(products) {
        const productList = document.getElementById('product-list');
        productList.innerHTML = '';
        products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.className = 'product';
            productDiv.innerHTML = ` 
                <img src="${product.image}" alt="${product.name}">
                <h2>${product.name}</h2>
                <p>${product.description}</p>
                <button class="add-to-cart">В корзину</button>
                <button class="like-button"><span class="heart">&hearts;</span></button>`;
            productList.appendChild(productDiv);

            // Добавляем обработчик события для кнопки "В корзину"
            const cartButton = productDiv.querySelector('.add-to-cart');
            cartButton.addEventListener('click', function() {
                if (cartButton.classList.contains('in-cart')) {
                    cartButton.classList.remove('in-cart');
                    cartButton.textContent = 'В корзину';
                    showNotification('Товар удален из Вашей корзины');
                } else {
                    cartButton.classList.add('in-cart');
                    cartButton.textContent = 'В корзине';
                    showNotification('Товар добавлен в Вашу корзину. Перейти к оформлению заказа');
                }
            });

            // Добавляем обработчик события для кнопки "Нравится"
            const likeButton = productDiv.querySelector('.like-button');
            likeButton.addEventListener('click', function() {
                likeButton.classList.toggle('liked');
            });
        });
    }

    // Функция для сортировки продуктов
    function sortProducts(order) {
        if (order === 'asc') {
            // Сортировка по возрастанию
            products = [products[8], products[9], products[3], products[10], products[11], products[4], products[0], products[1], products[5], products[6], products[7], products[2]];
        } else if (order === 'desc') {
            // Сортировка по убыванию
            products = [products[2], products[7], products[6], products[5], products[1], products[0], products[4], products[11], products[10], products[3], products[9], products[8]];
        }
        displayProducts(products);
    }

    // Загрузка продуктов и инициализация сортировки
    if (document.getElementById('product-list')) {
        fetch('data/data.json')
            .then(response => response.json()) // Преобразуем ответ в JSON
            .then(data => {
                products = data.products; // Сохраняем продукты в переменную
                displayProducts(products); // Отображаем продукты

                
                const sortSelect = document.getElementById('sort-select');
                sortSelect.addEventListener('change', function() {
                    const sortOrder = this.value;
                    sortProducts(sortOrder);
                });
            });
    }

    // Отправка данных формы с использованием fetch
    const form = document.getElementById('contact-form'); // Получаем форму по ID
    if (form) {
        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Предотвращаем отправку формы по умолчанию

            // Собираем данные формы
            const formData = new FormData(form);
            const formDataObject = {};
            formData.forEach((value, key) => {
                formDataObject[key] = value;
            });

            // Отправляем данные на сервер
            fetch('http://localhost/contact_form/save_contact.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formDataObject)
            })
            .then(response => {
                // Проверяем, если ответ от сервера не является JSON, то показываем ошибку
                if (!response.ok) {
                    throw new Error('Ошибка при отправке данных на сервер');
                }

                return response.json();
            })
            .then(data => {
                console.log('Ответ от сервера:', data);
                showNotification('Сообщение отправлено успешно!');
            })
            .catch(error => {
                console.error('Ошибка:', error);
                showNotification('Произошла ошибка при отправке сообщения');
            });
        });
    }

    // Отображение списка пользователей из localStorage
    if (document.getElementById('user-list')) {
        let users = JSON.parse(localStorage.getItem('users')) || [];
        const userList = document.getElementById('user-list');
        users.forEach(user => {
            const userDiv = document.createElement('div');
            userDiv.className = 'user';
            userDiv.innerHTML = `<p><strong>Имя:</strong> ${user.name}</p>
                                 <p><strong>Email:</strong> ${user.email}</p>
                                 <p><strong>Сообщение:</strong> ${user.message}</p>
                                 <p><strong>Дата:</strong> ${user.date}</p>`;
            userList.appendChild(userDiv);
        });
    }

    // Обработчик для кнопки "Загрузить еще"
    const loadMoreBtn = document.getElementById('load-more-btn');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            var btn = document.getElementById('load-more-btn');
            var gif = document.getElementById('loading-gif');

            // Скрыть кнопку и показать GIF
            btn.style.display = 'none';
            gif.style.display = 'block';

            // Имитация загрузки данных
            setTimeout(function() {
                gif.style.display = 'none';
                btn.style.display = 'block';
            }, 2000);
        });
    }

    // Функция для показа страницы 404
    function show404Page() {
        document.body.innerHTML = `
            <h1>404</h1>
            <h2>Страница не найдена</h2>
            <a href="/">Вернуться на главную</a>
        `;
    }

    
    const articlesLink = document.getElementById('articles-link');
    if (articlesLink) {
        articlesLink.addEventListener('click', function(event) {
            event.preventDefault();
            show404Page();
        });
    }
});
